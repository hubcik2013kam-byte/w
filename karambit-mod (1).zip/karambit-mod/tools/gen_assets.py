#!/usr/bin/env python3
"""Generuje tekstury 16x16, modele i definicje itemow dla wszystkich karambitow.
Uruchom:  python3 tools/gen_assets.py   (wymaga Pillow)
Kazdy karambit = ksztalt x kolor A x kolor B (gradient ostrza od A do B).
Nazwa: k<ksztalt>_<A>_<B>   np. k0_3_5
"""
import json, math, os, sys
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "karambitmod")
PAL = [(220, 40, 50), (255, 140, 30), (250, 220, 50), (60, 200, 80), (50, 220, 230),
       (50, 100, 240), (150, 70, 220), (255, 110, 190), (240, 240, 245), (35, 35, 45)]

# ksztalt: (Ox, Oy, Or, Ix, Iy, Ir)  -> polksiezyc = kolo O minus kolo I
SHAPES = [
    (7.0, 9.0, 7.4, 9.4, 11.4, 6.4),   # 0 klasyczny
    (7.5, 8.5, 7.6, 9.2, 10.3, 7.0),   # 1 cienki "hawk"
    (6.5, 9.5, 7.2, 9.6, 12.2, 5.6),   # 2 gruby
]
HANDLE = ((1.8, 14.2), (5.2, 10.8))     # od (x,y) do (x,y)
RING = (2.0, 13.8, 2.3)                 # srodek + promien
BLADE_FROM, BLADE_TO = (3.5, 12.0), (14.0, 2.5)


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def dist_seg(px, py, a, b):
    ax, ay = a; bx, by = b
    dx, dy = bx - ax, by - ay
    t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def render(shape, ca, cb):
    ox, oy, orr, ix, iy, ir = SHAPES[shape]
    role = {}
    for y in range(16):
        for x in range(16):
            px, py = x + 0.5, y + 0.5
            in_o = math.hypot(px - ox, py - oy) <= orr
            in_i = math.hypot(px - ix, py - iy) <= ir
            if in_o and not in_i:
                role[(x, y)] = "blade"
    for y in range(16):
        for x in range(16):
            px, py = x + 0.5, y + 0.5
            if dist_seg(px, py, *HANDLE) <= 1.2:
                role[(x, y)] = "handle"
    cx, cy, cr = RING
    for y in range(16):
        for x in range(16):
            d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
            if cr - 1.0 <= d <= cr:
                role[(x, y)] = "ring"
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    bx, by = BLADE_TO[0] - BLADE_FROM[0], BLADE_TO[1] - BLADE_FROM[1]
    bl = bx * bx + by * by
    for (x, y), r in role.items():
        if r == "blade":
            t = ((x + 0.5 - BLADE_FROM[0]) * bx + (y + 0.5 - BLADE_FROM[1]) * by) / bl
            t = max(0, min(1, t))
            c = lerp(PAL[ca], PAL[cb], t)
            # krawedz tnaca (strona wewnetrzna) jasniejsza
            ddi = math.hypot(x + 0.5 - ix, y + 0.5 - iy) - ir
            if ddi < 1.0:
                c = lerp(c, (255, 255, 255), 0.45)
            img.putpixel((x, y), c + (255,))
        elif r == "handle":
            img.putpixel((x, y), (48, 48, 56, 255) if (x + y) % 2 else (64, 64, 74, 255))
        else:
            img.putpixel((x, y), (185, 190, 200, 255))
    # obrys
    out = img.copy()
    for y in range(16):
        for x in range(16):
            if img.getpixel((x, y))[3] == 0:
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 16 and 0 <= ny < 16 and img.getpixel((nx, ny))[3] and (dx == 0 or dy == 0):
                            out.putpixel((x, y), (12, 12, 16, 255))
    return out


def main():
    tex = os.path.join(ROOT, "textures", "item")
    mdl = os.path.join(ROOT, "models", "item")
    itm = os.path.join(ROOT, "items")
    n = 0
    for s in range(len(SHAPES)):
        for a in range(len(PAL)):
            for b in range(len(PAL)):
                name = f"k{s}_{a}_{b}"
                render(s, a, b).save(os.path.join(tex, name + ".png"))
                with open(os.path.join(mdl, name + ".json"), "w") as f:
                    json.dump({"parent": "minecraft:item/handheld",
                               "textures": {"layer0": f"karambitmod:item/{name}"}}, f)
                with open(os.path.join(itm, name + ".json"), "w") as f:
                    json.dump({"model": {"type": "minecraft:model", "model": f"karambitmod:item/{name}"}}, f)
                n += 1
    print("wygenerowano", n, "karambitow")
    # podglad
    if "--preview" in sys.argv:
        sheet = Image.new("RGBA", (16 * 3 * 8, 16 * 4 * 8), (90, 90, 90, 255))
        for s in range(3):
            for k, (a, b) in enumerate([(0, 5), (1, 2), (6, 7), (4, 6)]):
                im = render(s, a, b).resize((128, 128), Image.NEAREST)
                sheet.paste(im, (s * 128, k * 128), im)
        sheet.save("/home/claude/preview.png")


if __name__ == "__main__":
    main()
