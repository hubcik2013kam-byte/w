package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Menu moda (klawisz P). Ciemny panel z gradientowym akcentem i własnymi widżetami. */
public class ConfigScreen extends Screen {
    private static final String[] TABS = {"Ogólne", "Karambit", "Cząsteczki", "Deszcz", "Spotify", "HUD"};
    private static final int PW = 440;
    private static final int ROW = 22;
    private static final int TOP = 60;
    private static int tab = 0;

    private final Screen parent;
    private int slot;
    private boolean dimmed;                                  // widżety po wyłączonym module są nieaktywne
    private final List<Object[]> labels = new ArrayList<>();    // {x, y, tekst}
    private final List<Object[]> swatches = new ArrayList<>();  // {x, y, IntSupplier}

    public ConfigScreen(Screen parent) {
        super(Text.literal("Karambit Mod"));
        this.parent = parent;
    }

    private int px() { return width / 2 - PW / 2; }

    // ============================================================ widżety

    /** Przycisk w stylu moda; opcjonalnie z przełącznikiem po prawej. */
    static class Btn extends ButtonWidget {
        private final BooleanSupplier selected, sw;
        private final boolean centered;

        Btn(int x, int y, int w, int h, net.minecraft.text.Text msg, PressAction act, BooleanSupplier selected, BooleanSupplier sw, boolean centered) {
            super(x, y, w, h, msg, act, DEFAULT_NARRATION_SUPPLIER);
            this.selected = selected; this.sw = sw; this.centered = centered;
        }

        // PressableWidget#renderWidget jest final; drawIcon wywoływane jest po tle vanilla,
        // więc rysujemy własny, w pełni kryjący przycisk na wierzchu.
        @Override
        public void drawIcon(DrawContext c, int mx, int my, float d) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean sel = selected != null && selected.getAsBoolean();
            boolean act = active;
            boolean hov = act && isHovered();
            c.fill(x, y, x + w, y + h, !act ? 0xFF25252F : sel ? 0xFF8A5CFF : hov ? 0xFF6A6A90 : 0xFF34344A);
            c.fill(x + 1, y + 1, x + w - 1, y + h - 1, !act ? 0xFF16161D : sel ? 0xFF2A2250 : hov ? 0xFF2B2B40 : 0xFF1E1E2A);
            int ty = y + (h - 8) / 2;
            int tc = act ? 0xFFFFFFFF : 0xFF666677;
            if (centered) c.drawCenteredTextWithShadow(tr, getMessage(), x + w / 2, ty, tc);
            else c.drawTextWithShadow(tr, getMessage(), x + 8, ty, tc);
            if (sw != null) {
                boolean on = sw.getAsBoolean();
                int sx = x + w - 32, sy = y + (h - 10) / 2;
                Gui.roundRect(c, sx, sy, sx + 24, sy + 10, !act ? 0xFF2A2A34 : on ? 0xFF000000 | Gui.ACCENT_A : 0xFF3A3A4A);
                if (on && act) Gui.hGradient(c, sx + 2, sy + 1, 20, 8, Gui.ACCENT_A, Gui.ACCENT_B);
                int kx = on ? sx + 14 : sx + 2;
                c.fill(kx, sy + 2, kx + 8, sy + 8, act ? 0xFFFFFFFF : 0xFF666677);
            }
        }
    }

    /** Suwak z gradientowym wypełnieniem. */
    abstract static class Sl extends SliderWidget {
        Sl(int x, int y, int w, int h, double v) { super(x, y, w, h, Text.empty(), v); }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float d) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean act = active;
            Gui.roundRect(c, x, y, x + w, y + h, !act ? 0xFF25252F : isHovered() ? 0xFF6A6A90 : 0xFF34344A);
            Gui.roundRect(c, x + 1, y + 1, x + w - 1, y + h - 1, act ? 0xFF1E1E2A : 0xFF16161D);
            int fill = (int) ((w - 4) * value);
            if (fill > 0) {
                if (act) Gui.hGradient(c, x + 2, y + h - 5, fill, 3, Gui.ACCENT_A, Gui.ACCENT_B);
                else c.fill(x + 2, y + h - 5, x + 2 + fill, y + h - 2, 0xFF3A3A48);
            }
            int kx = x + 2 + fill - 2;
            c.fill(kx, y + 3, kx + 4, y + h - 3, act ? 0xFFFFFFFF : 0xFF666677);
            c.drawCenteredTextWithShadow(tr, getMessage(), x + w / 2, y + 4, act ? 0xFFFFFFFF : 0xFF666677);
        }
    }

    // ============================================================ układ

    private int nextX() { return px() + 14 + (slot % 2) * 212; }
    private int nextY() { return TOP + (slot / 2) * ROW; }
    private void skipToNextRow() { if (slot % 2 == 1) slot++; }

    @Override
    protected void init() {
        labels.clear();
        swatches.clear();
        slot = 0;
        dimmed = false;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            addDrawableChild(new Btn(px() + 6 + i * 72, 30, 68, 20, Text.literal(TABS[i]),
                    b -> { tab = idx; clearAndInit(); }, () -> tab == idx, null, true));
        }
        switch (tab) {
            case 0 -> initGeneral();
            case 1 -> initKarambit();
            case 2 -> initParticles();
            case 3 -> initRain();
            case 4 -> initSpotify();
            default -> initHud();
        }
        dimmed = false;
        addDrawableChild(new Btn(width / 2 - 100, height - 30, 200, 20, Text.literal("Gotowe"),
                b -> close(), () -> false, null, true));
    }

    @Override public void removed() { Cfg.save(); }

    @Override
    public void close() {
        Cfg.save();
        if (client != null) client.setScreen(parent);
    }

    // ============================================================ zakładki

    private void initGeneral() {
        Cfg c = Cfg.I;
        master("Mod włączony (wszystko)", () -> c.modEnabled, v -> c.modEnabled = v);
        addDrawableChild(new Btn(nextX(), nextY(), 200, 20, Text.literal("Przywróć ustawienia domyślne"),
                b -> { Cfg.resetKeepingSpotify(); clearAndInit(); }, () -> false, null, false));
        slot++;
        toggle("Karambit zamiast mieczy", () -> c.karambitEnabled, v -> c.karambitEnabled = v);
        toggle("Cząsteczki", () -> c.particlesEnabled, v -> c.particlesEnabled = v);
        toggle("Deszcz (odbijające się krople)", () -> c.rainEnabled, v -> c.rainEnabled = v);
        toggle("Spotify (połączenie i sterowanie)", () -> c.spotifyEnabled, v -> c.spotifyEnabled = v);
        toggle("Okienko \"Teraz gra\"", () -> c.hudEnabled, v -> c.hudEnabled = v);
    }

    private void initKarambit() {
        Cfg c = Cfg.I;
        master("Karambit zamiast mieczy", () -> c.karambitEnabled, v -> c.karambitEnabled = v);
        cycle("Kształt", new Integer[]{0, 1, 2}, () -> c.karambitShape, v -> c.karambitShape = v, v -> Cfg.SHAPE_NAMES[v]);
        Integer[] pal = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        cycle("Kolor A (rękojeść)", pal, () -> c.karambitColorA, v -> c.karambitColorA = v, v -> Cfg.PALETTE_NAMES[v]);
        cycle("Kolor B (czubek)", pal, () -> c.karambitColorB, v -> c.karambitColorB = v, v -> Cfg.PALETTE_NAMES[v]);
    }

    private void initParticles() {
        Cfg c = Cfg.I;
        master("Cząsteczki", () -> c.particlesEnabled, v -> c.particlesEnabled = v);
        toggle("Tylko z mieczem w ręce", () -> c.onlyWithSword, v -> c.onlyWithSword = v);
        cycle("Miejsce", Cfg.Anchor.values(), () -> c.anchor, v -> c.anchor = v, v -> switch (v) {
            case HELD_ITEM -> "Miecz w ręce";
            case TARGET_BLOCK -> "Wskazywany blok";
            case PLAYER -> "Wokół gracza";
        });
        cycle("Kształt", Cfg.PShape.values(), () -> c.particleShape, v -> c.particleShape = v, v -> switch (v) {
            case ORBIT -> "Orbita";
            case HELIX -> "Spirala";
            case RING -> "Pierścień";
            case STAR -> "Gwiazda";
            case HEART -> "Serce";
            case CUBE -> "Sześcian";
            case SPHERE -> "Sfera";
            case CLOUD -> "Chmura";
            case LINE -> "Smuga";
        });
        cycle("Typ", Cfg.PType.values(), () -> c.particleType, v -> c.particleType = v, v -> switch (v) {
            case DUST -> "Kolorowy pył";
            case END_ROD -> "Iskry Endu";
            case FLAME -> "Ogień";
            case SOUL_FIRE -> "Ogień dusz";
            case ELECTRIC_SPARK -> "Elektryczne";
            case HAPPY_VILLAGER -> "Zielone gwiazdki";
        });
        toggle("Gradient kolorów", () -> c.particleGradient, v -> c.particleGradient = v);
        hex("Kolor A (hex)", () -> c.particleColorA, v -> c.particleColorA = v);
        hex("Kolor B (hex)", () -> c.particleColorB, v -> c.particleColorB = v);
        slider("Ilość / tick", 1, 40, () -> c.particleCount, v -> c.particleCount = (int) Math.round(v), "%.0f");
        slider("Rozmiar", 0.3, 3, () -> c.particleSize, v -> c.particleSize = (float) v, "%.1f");
        slider("Promień", 0.2, 2.5, () -> c.particleRadius, v -> c.particleRadius = (float) v, "%.2f");
        slider("Prędkość", 0.1, 4, () -> c.particleSpeed, v -> c.particleSpeed = (float) v, "%.1f");
    }

    private void initRain() {
        Cfg c = Cfg.I;
        master("Odbijające się krople", () -> c.rainEnabled, v -> c.rainEnabled = v);
        toggle("Plusk po upadku", () -> c.rainSplash, v -> c.rainSplash = v);
        slider("Gęstość", 1, 15, () -> c.rainDensity, v -> c.rainDensity = (int) Math.round(v), "%.0f");
        slider("Sprężystość", 0.2, 0.9, () -> c.rainBounce, v -> c.rainBounce = (float) v, "%.2f");
        slider("Rozmiar kropli", 0.3, 2, () -> c.rainSize, v -> c.rainSize = (float) v, "%.1f");
        slider("Zasięg", 4, 24, () -> c.rainRadius, v -> c.rainRadius = (float) v, "%.0f bl.");
        toggle("Gradient kolorów", () -> c.rainGradient, v -> c.rainGradient = v);
        skipToNextRow();
        hex("Kolor A (hex)", () -> c.rainColorA, v -> c.rainColorA = v);
        hex("Kolor B (hex)", () -> c.rainColorB, v -> c.rainColorB = v);
    }

    private void initSpotify() {
        Cfg c = Cfg.I;
        int cx = width / 2;
        Btn m = new Btn(cx - 100, 58, 200, 20, Text.literal("Spotify włączony"),
                btn -> { c.spotifyEnabled = !c.spotifyEnabled; clearAndInit(); }, () -> false, () -> c.spotifyEnabled, false);
        addDrawableChild(m);
        dimmed = !c.spotifyEnabled;

        labels.add(new Object[]{cx - 100, 83, "Spotify Client ID"});
        TextFieldWidget id = new TextFieldWidget(textRenderer, cx - 100, 93, 200, 20, Text.literal("Client ID"));
        id.setMaxLength(64);
        id.setPlaceholder(Text.literal("Wklej Client ID z developer.spotify.com"));
        id.setText(c.spotifyClientId);
        id.setChangedListener(s -> c.spotifyClientId = s.trim());
        id.setEditable(!dimmed);
        addDrawableChild(id);

        put(new Btn(cx - 100, 117, 98, 20, Text.literal("Połącz"), b -> { Cfg.save(); Spotify.connect(); }, () -> false, null, true));
        put(new Btn(cx + 2, 117, 98, 20, Text.literal("Odłącz"), b -> Spotify.disconnect(), () -> false, null, true));

        labels.add(new Object[]{cx - 100, 159, "Sterowanie (wymaga Premium)"});
        put(new Btn(cx - 100, 169, 64, 20, Text.literal("⏮"), b -> Spotify.previous(), () -> false, null, true));
        put(new Btn(cx - 32, 169, 64, 20, Text.literal("⏯"), b -> Spotify.playPause(), () -> false, null, true));
        put(new Btn(cx + 36, 169, 64, 20, Text.literal("⏭"), b -> Spotify.next(), () -> false, null, true));
        labels.add(new Object[]{cx - 100, 195, "Redirect URI: §ahttp://127.0.0.1:8888/callback"});
    }

    private void initHud() {
        Cfg c = Cfg.I;
        master("Pokaż \"Teraz gra\"", () -> c.hudEnabled, v -> c.hudEnabled = v);
        toggle("Pasek postępu", () -> c.hudProgress, v -> c.hudProgress = v);
        toggle("Gradient tekstu", () -> c.hudGradient, v -> c.hudGradient = v);
        skipToNextRow();
        hex("Kolor A (hex)", () -> c.hudColorA, v -> c.hudColorA = v);
        hex("Kolor B (hex)", () -> c.hudColorB, v -> c.hudColorB = v);
        slider("Pozycja X", 0, 100, () -> c.hudX, v -> c.hudX = (float) v, "%.0f%%");
        slider("Pozycja Y", 0, 100, () -> c.hudY, v -> c.hudY = (float) v, "%.0f%%");
        slider("Skala", 0.5, 2.5, () -> c.hudScale, v -> c.hudScale = (float) v, "%.1f");
    }

    // ============================================================ fabryki widżetów

    private <T extends ClickableWidget> T put(T w) {
        w.active = !dimmed;
        return addDrawableChild(w);
    }

    /** Główny włącznik zakładki: po wyłączeniu reszta opcji jest przyciemniona i nieaktywna. */
    private void master(String label, BooleanSupplier get, Consumer<Boolean> set) {
        Btn b = new Btn(nextX(), nextY(), 200, 20, Text.literal(label),
                btn -> { set.accept(!get.getAsBoolean()); clearAndInit(); }, () -> false, get, false);
        slot++;
        addDrawableChild(b);
        dimmed = !get.getAsBoolean();
    }

    private void toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        Btn b = new Btn(nextX(), nextY(), 200, 20, Text.literal(label),
                btn -> set.accept(!get.getAsBoolean()), () -> false, get, false);
        slot++;
        put(b);
    }

    private <T> void cycle(String label, T[] values, Supplier<T> get, Consumer<T> set, Function<T, String> name) {
        Btn b = new Btn(nextX(), nextY(), 200, 20, Text.literal(label + ": " + name.apply(get.get())), btn -> {
            int idx = 0;
            for (int i = 0; i < values.length; i++) if (values[i].equals(get.get())) idx = i;
            T nv = values[(idx + 1) % values.length];
            set.accept(nv);
            btn.setMessage(Text.literal(label + ": " + name.apply(nv)));
        }, () -> false, null, false);
        slot++;
        put(b);
    }

    private void slider(String label, double min, double max, DoubleSupplier get, DoubleConsumer set, String fmt) {
        final double span = max - min;
        Sl w = new Sl(nextX(), nextY(), 200, 20, (get.getAsDouble() - min) / span) {
            { updateMessage(); }
            @Override protected void updateMessage() {
                setMessage(Text.literal(label + ": " + String.format(fmt, min + value * span)));
            }
            @Override protected void applyValue() { set.accept(min + value * span); }
        };
        slot++;
        put(w);
    }

    private void hex(String label, IntSupplier get, IntConsumer set) {
        int x = nextX(), y = nextY();
        labels.add(new Object[]{x + 4, y + 6, label});
        swatches.add(new Object[]{x + 98, y + 3, get});
        TextFieldWidget f = new TextFieldWidget(textRenderer, x + 120, y, 80, 20, Text.literal(label));
        f.setMaxLength(6);
        f.setText(String.format("%06X", get.getAsInt() & 0xFFFFFF));
        f.setChangedListener(s -> {
            if (s.length() == 6) {
                try { set.accept(Integer.parseInt(s, 16)); } catch (NumberFormatException ignored) {}
            }
        });
        slot++;
        f.setEditable(!dimmed);
        addDrawableChild(f);
    }

    // ============================================================ rysowanie

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        int x = px();
        Gui.roundRect(ctx, x - 1, 7, x + PW + 1, height - 5, 0xFF2E2E44);
        Gui.roundRect(ctx, x, 8, x + PW, height - 6, 0xF0121219);
        Gui.hGradient(ctx, x + 3, 8, PW - 6, 2, Gui.ACCENT_A, Gui.ACCENT_B);
        String title = "Karambit Mod";
        ctx.drawTextWithShadow(textRenderer, Gui.gradientText(title, Gui.ACCENT_A, Gui.ACCENT_B),
                width / 2 - textRenderer.getWidth(title) / 2 - 2, 15, 0xFFFFFFFF);
        ctx.fill(x + 12, 54, x + PW - 12, 55, 0xFF2A2A3C);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        for (Object[] l : labels)
            ctx.drawTextWithShadow(textRenderer, Text.literal((String) l[2]), (int) l[0], (int) l[1], 0xFFBBBBCC);
        for (Object[] s : swatches) {
            int sx = (int) s[0], sy = (int) s[1];
            int col = ((IntSupplier) s[2]).getAsInt();
            Gui.roundRect(ctx, sx - 1, sy - 1, sx + 15, sy + 15, 0xFF4A4A60);
            ctx.fill(sx, sy, sx + 14, sy + 14, 0xFF000000 | col);
        }
        Cfg c = Cfg.I;
        int cx = width / 2;
        switch (tab) {
            case 0 -> ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Klawisz menu: P (zmiana: Opcje → Sterowanie → Karambit Mod)"), cx, TOP + 4 * ROW + 8, 0xFF888899);
            case 1 -> {
                int fy = TOP + 2 * ROW + 6;
                Gui.roundRect(ctx, cx - 46, fy, cx + 46, fy + 84, 0xFF2A2A3C);
                Gui.roundRect(ctx, cx - 45, fy + 1, cx + 45, fy + 83, 0xFF181822);
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(cx - 32, fy + 10);
                ctx.getMatrices().scale(4f, 4f);
                ctx.drawItem(new ItemStack(Items.DIAMOND_SWORD), 0, 0);   // mixin podmienia go na karambita
                ctx.getMatrices().popMatrix();
                Gui.hGradient(ctx, cx - 100, fy + 90, 200, 4, palette(c.karambitColorA), palette(c.karambitColorB));
                if (height >= 260)
                    ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Podgląd na żywo, dotyczy wszystkich mieczy."), cx, fy + 100, 0xFF888899);
            }
            case 3 -> {
                int fy = TOP + 5 * ROW + 6;
                Gui.hGradient(ctx, cx - 100, fy, 200, 4, c.rainColorA, c.rainGradient ? c.rainColorB : c.rainColorA);
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Krople pojawiają się tylko na odkrytym terenie, gdy pada deszcz."), cx, fy + 10, 0xFF888899);
            }
            case 4 -> {
                String st = Spotify.status;
                boolean ok = c.spotifyEnabled && Spotify.isLinked() && !st.startsWith("Błąd") && !st.contains("Premium");
                Gui.roundRect(ctx, cx - 100, 141, cx + 100, 155, 0xFF1E1E2A);
                ctx.fill(cx - 94, 145, cx - 88, 151, ok ? 0xFF1DB954 : 0xFFE5484D);
                ctx.drawTextWithShadow(textRenderer, Text.literal(st), cx - 82, 144, 0xFFFFFFFF);
            }
            case 5 -> {
                Gui.hGradient(ctx, cx - 100, TOP + 4 * ROW + 8, 200, 4, c.hudColorA, c.hudGradient ? c.hudColorB : c.hudColorA);
                Spotify.Track t = Spotify.track;
                if (t == null) t = new Spotify.Track("Przykładowy utwór", "Wykonawca", 63000, 215000, true, System.currentTimeMillis());
                if (c.hudEnabled && c.modEnabled) HudRenderer.draw(ctx, textRenderer, t, width, height);   // podgląd na żywo
            }
            default -> {}
        }
    }

    private static int palette(int idx) {
        int[] p = {0xDC2832, 0xFF8C1E, 0xFADC32, 0x3CC850, 0x32DCE6, 0x3264F0, 0x9646DC, 0xFF6EBE, 0xF0F0F5, 0x23232D};
        return p[Cfg.clamp(idx, 0, 9)];
    }
}
