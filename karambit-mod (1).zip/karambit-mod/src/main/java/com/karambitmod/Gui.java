package com.karambitmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/** Małe narzędzia do rysowania ładniejszego GUI (zaokrąglone prostokąty, gradienty). */
public final class Gui {
    public static final int ACCENT_A = 0x8A5CFF;
    public static final int ACCENT_B = 0x33CCFF;

    private Gui() {}

    /** Prostokąt z zaokrąglonymi rogami (promień 2 px). Kolor ARGB. */
    public static void roundRect(DrawContext c, int x1, int y1, int x2, int y2, int argb) {
        c.fill(x1 + 2, y1, x2 - 2, y2, argb);
        c.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, argb);
        c.fill(x1, y1 + 2, x2, y2 - 2, argb);
    }

    public static void hGradient(DrawContext c, int x, int y, int w, int h, int a, int b) {
        for (int i = 0; i < w; i++) c.fill(x + i, y, x + i + 1, y + h, 0xFF000000 | Cfg.lerp(a, b, (float) i / Math.max(1, w - 1)));
    }

    public static void vGradient(DrawContext c, int x, int y, int w, int h, int a, int b) {
        for (int i = 0; i < h; i++) c.fill(x, y + i, x + w, y + i + 1, 0xFF000000 | Cfg.lerp(a, b, (float) i / Math.max(1, h - 1)));
    }

    public static MutableText gradientText(String s, int a, int b) {
        MutableText out = Text.empty();
        int n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            out.append(Text.literal(String.valueOf(s.charAt(i))).setStyle(Style.EMPTY.withColor(Cfg.lerp(a, b, (float) i / n)).withBold(true)));
        }
        return out;
    }
}
