package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Gdy pada deszcz, na ziemi wokół gracza pojawiają się krople, które podskakują
 * (kilka odbić ze stratą energii) i kończą małym pluskiem. Czysto kliencki efekt.
 */
public final class RainEngine {
    private static final class Drop {
        double x, y, z, vx, vy, vz, ground;
        int bounces;
        int color;
    }

    private static final List<Drop> DROPS = new ArrayList<>();
    private static final Random R = new Random();
    private static final int MAX_DROPS = 250;
    private static final int MAX_BOUNCES = 3;
    private static final double GRAVITY = 0.045;
    private static long age;

    private RainEngine() {}

    public static void tick(MinecraftClient mc) {
        Cfg c = Cfg.I;
        ClientWorld w = mc.world;
        if (w == null || mc.player == null || !c.modEnabled || !c.rainEnabled) { DROPS.clear(); return; }
        if (mc.isPaused()) return;
        age++;

        float rain = w.getRainGradient(1f);
        if (rain > 0.2f) {
            int n = Math.round(c.rainDensity * rain);
            for (int i = 0; i < n && DROPS.size() < MAX_DROPS; i++) spawn(mc, w, c);
        }

        Iterator<Drop> it = DROPS.iterator();
        while (it.hasNext()) {
            Drop d = it.next();
            d.vy -= GRAVITY;
            d.x += d.vx; d.y += d.vy; d.z += d.vz;
            if (d.y <= d.ground && d.vy < 0) {
                d.y = d.ground;
                if (d.bounces >= MAX_BOUNCES || Math.abs(d.vy) < 0.06) {
                    if (c.rainSplash) splash(w, d, c);
                    it.remove();
                    continue;
                }
                d.vy = -d.vy * c.rainBounce;
                d.vx *= 0.7; d.vz *= 0.7;
                d.bounces++;
            }
            if ((age & 1) == 0) {
                w.addParticleClient(new DustParticleEffect(d.color, c.rainSize), d.x, d.y, d.z, 0, 0, 0);
            }
        }
    }

    private static void spawn(MinecraftClient mc, ClientWorld w, Cfg c) {
        double ang = R.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(R.nextDouble()) * c.rainRadius;
        double x = mc.player.getX() + Math.cos(ang) * r;
        double z = mc.player.getZ() + Math.sin(ang) * r;
        int bx = MathHelper.floor(x), bz = MathHelper.floor(z);
        int top = w.getTopY(Heightmap.Type.MOTION_BLOCKING, bx, bz);
        if (Math.abs(top - mc.player.getY()) > 10) return;
        if (!w.hasRain(new BlockPos(bx, top, bz))) return;   // pod dachem / w biomie bez deszczu: pomijamy

        Drop d = new Drop();
        d.x = x; d.z = z; d.ground = top + 0.02; d.y = d.ground;
        d.vy = 0.10 + R.nextDouble() * 0.12;
        d.vx = (R.nextDouble() - 0.5) * 0.04;
        d.vz = (R.nextDouble() - 0.5) * 0.04;
        d.color = c.rainGradient ? Cfg.lerp(c.rainColorA, c.rainColorB, R.nextFloat()) : c.rainColorA;
        DROPS.add(d);
    }

    private static void splash(ClientWorld w, Drop d, Cfg c) {
        for (int i = 0; i < 5; i++) {
            double a = i * Math.PI * 2 / 5 + R.nextDouble() * 0.5;
            w.addParticleClient(new DustParticleEffect(d.color, c.rainSize * 0.7f), d.x, d.y + 0.02, d.z,
                    Math.cos(a) * 0.03, 0.02, Math.sin(a) * 0.03);
        }
    }
}
