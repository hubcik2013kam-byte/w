package com.karambitmod.mixin;

import com.karambitmod.Cfg;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Podmienia model każdego miecza (tag minecraft:swords) na wybranego karambita.
 * Działa wszędzie: w ręce, w GUI, na ziemi, w ramce.
 *
 * Jeśli po aktualizacji Minecrafta mixin przestanie się wiązać, sprawdź w IDE
 * metodę ItemModelManager#update i ustaw @At na miejsce, gdzie czytany jest
 * DataComponentTypes.ITEM_MODEL (zmienna typu Identifier).
 */
@Mixin(ItemModelManager.class)
public class ItemModelManagerMixin {

    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 0)
    private Identifier karambitmod$swapModel(Identifier original, @Local(argsOnly = true) ItemStack stack) {
        if (Cfg.I.modEnabled && Cfg.I.karambitEnabled && stack != null && stack.isIn(ItemTags.SWORDS)) {
            return Identifier.of("karambitmod", Cfg.I.karambitModelId());
        }
        return original;
    }
}
